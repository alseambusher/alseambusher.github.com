function _get(){
	if (window.XMLHttpRequest) {
		var req = new XMLHttpRequest();
		if(!req){
  			// code for IE6, IE5
  			req=new ActiveXObject("Microsoft.XMLHTTP");
  		}
		req.onreadystatechange=function(){
			if (req.readyState == 4) {
			document.getElementById("output").innerHTML=req.responseText;
				console.log(req.responseText)
			}
		}
		req.open("GET", "get_ajax.htm", true);
		req.send("");
	}
}

function _post(){
	if (window.XMLHttpRequest) {
		var req = new XMLHttpRequest();
		req.open("POST", "post_ajax.php", true);
		req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		req.onreadystatechange=function(){
			if (req.readyState == 4) {
				document.getElementById("output").innerHTML=req.responseText;
				console.log(req.responseText)
			}
		}
		req.send("num1="+document.getElementById("num1").value+"&num2="+document.getElementById("num2").value);
	}
}

function _clear(){
	document.getElementById("output").innerHTML="";
}

