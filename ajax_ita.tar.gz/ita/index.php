<!doctype html>
<html>
<head>
<link rel="stylesheet" href="bootstrap.css" />
<script src="welcome.js"></script>
</head>
<body>
<h1>Ajax tutorial</h1>
<button class="btn btn-primary" onclick="_get();">GET</button>
<button class="btn btn-primary" onclick="_post();">POST</button>
<button class="btn btn-primary" onclick="_clear();">clear</button>
<br>
<input type="text" class="form-control" style="width:200px" placeholder="number" id="num1"/>
<input type="text" class="form-control" style="width:200px" placeholder="number" id="num2"/>
<div id="output"></div>
</body>
</html>
