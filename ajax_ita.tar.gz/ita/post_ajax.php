<?
print_r($_POST);
echo "<br>"+$_POST["num1"]+$_POST["num2"];
//echo $_POST["number1"]+$_POST["number2"];
?>
